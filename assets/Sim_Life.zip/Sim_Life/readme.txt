Hi there! Welcome to the SimLife README.TXT file. This file 
includes additions to the manual as well as hints, a small 
Q&A portion, a few "cheats" to help you out, and much much 
more!

I.  UNDOCUMENTED KEYBOARD COMMANDS

Shift-W opens the World Building Options Window
Shift-R opens the Run Control Window
Shift-P opens the Populate Window
Shift-Z resets the digital clock to zero
Shift-B opens the Build World Window (asking if you wish to 
save the game first)

Holding down the Ctrl key and clicking on the left or right 
species scroll buttons on the dashboard will scroll the 
species by a page instead of scrolling by a single species.
Alt-clicking on left/right species scroll buttons will move
highlight one species.

Holding down the Shift key while opening a graph window will 
not close any other graph windows open at the time. 
(Normally, SimLife only allows the user to have one graph 
window open at any time.)

Pressing any of the HOME, END, PAGEUP, or PAGEDOWN keys 
twice will scroll the screen left, right, up, or down 
respectively. Pressing either key a 3rd time will stop the 
scrolling.

Holding down the Alt key while selecting Reconverge Species 
in the Simulation/Technical menu will reconverge only plant 
species.

Holding down the Ctrl key while selecting Reconverge Species 
in the Simulation/Technical menu will reconverge only animal 
species.

II.  SYSTEM-RELATED INFORMATION

-> Video Cards
SimLife will do its best to figure out what kind of video 
card you have and install itself appropriately, but there 
are some cards it just won't understand. If you install 
SimLife in 800x600 mode and your screen comes up a mess of 
graphics, or just plain blank, try running the installation 
program from the SimLife directory and changing the video 
mode to 640x480. Note that if the installer is unable to 
detect whether your video card will run in hi-res, it will 
not give you the option of installing for 800x600. 

-> Transferring Files Between Macintosh and PC SimLife
Saved Worlds, Zoos, Plants, and Animals from the Macintosh 
version of SimLife are compatible with the PC version of 
SimLife and vice versa. When taking Macintosh files to the 
PC, you must transfer the files via modem. Copying the files 
to an MS-DOS disk with any of the popular programs that 
allow the Macintosh to read MS-DOS disks will not work--not 
even with Apple File Exchange (bummer).

-> Cordless Mice
We have experienced a problem with some Logitech Cordless 
mice displaying erratic cursor behavior when doing certain 
things in the Edit Window. THIS IS NOT A PROBLEM WITH YOUR 
MOUSE! This is a problem with the way SimLife handles the 
data it is receiving from the mouse. At this time, we have 
no fix for this. If you do have a problem, call Maxis 
Technical Support and as soon as a patch becomes available 
to us, we will make it available to you.

-> Sounds
SimLife supports PC Speaker (as best we could), Adlib, 
Covox, Soundblaster, Soundblaster Pro (and 100& 
compatibles), and the Roland MPU-401 interface (that means 
the MT-32, LAPC-1, SCC-1, and other Roland MIDI devices). If 
you should be lucky enough to have a Soundblaster AND Roland 
installed in the same machine, you should be able to hear 
MIDI information through the Roland and digitized sounds 
through the Soundblaster. Note that in the interests of your 
sanity, SimLife will install with all sounds turned off if 
you are installing for the PC Speaker. Sounds can easily be 
turned on in the Goodies submenu of the Simulation Menu 
inside SimLife.

-> Fast Machines, Small Hard Disks, and Huge Games
Saved game files can get VERY large. In the process of 
testing, we have generated saved games over 11 megabytes in 
size. Needless to say, it can take quite some time to save 
and load this much information. Plan ahead. Get some coffee. 
Remind your family that you're still around. Huge games also 
can take forever to process. Unless you are running a very 
fast machine, we recommend that you do not run Medium or 
Large worlds at all. We have witnessed situations where it 
can take between 15 and 30 minutes PER TICK (this is even on 
486/33mhz machines). If you wish to make changes to your 
world when it is working this hard, click on the Pause 
button (you may not see it do anything until the next tick 
comes around). Once it is paused all of the menus and
options will be available to you without delay. If it is 
taking too long, go to Change Physics and reduce your plant 
limit or animal limit to gain speed. Also, the simulation 
pauses at midnight to update information. Be prepared for
this to take a little while if you are heavily taxing the 
system. Don't be fooled into thinking that the program 
crashed.

-> SimLife and Microsoft Windows
Don't run SimLife from within Microsoft Windows. There are
too many memory conflicts.

-> Boot Disks
If for some reason, you just can't get SimLife to work on 
your machine, try making a Boot Disk. It's possible that 
your system is automatically loading a program that is 
incompatible with SimLife. By making a Boot Disk, you bypass 
your regular AUTOEXEC.BAT and CONFIG.SYS that might normally 
load other programs.

To make a boot disk:
Step 1. Place a blank disk in the A: drive and FORMAT it 
with the DOS command by typing FORMAT A: /S. This will 
format the disk and copy your system files onto it all in 
one step, making it bootable.

Step 2. Copy your mouse driver, usually called MOUSE.COM or 
MOUSE.SYS, to the boot disk. This driver is usually located 
in a directory called \MOUSE.

Step 3. Create an AUTOEXEC.BAT file on your boot disk to 
load the mouse and boot SimLife.
    1) Type A:[ENTER]
    2) Type COPY CON AUTOEXEC.BAT[ENTER]
    3) Type PROMPT $P$G
    4) Type MOUSE[ENTER] (if you are using MOUSE.COM)
    5) Type C:[ENTER]
    6) Type CD \SIMLIFE[ENTER]
    7) Type SIMLIFE[ENTER]
    8) Press the F6 key, then [ENTER].

If SimLife is not in C:\SIMLIFE, change lines 5 and 6 to the 
correct drive and directory. If you are using a MOUSE.SYS 
file instead of MOUSE.COM, remove line 4 and add the 
MOUSE.SYS line in your CONFIG.SYS.

Step 4. Create a CONFIG.SYS file on your boot disk similar 
to the way you create the AUTOEXEC.BAT.
    1) Type A:[ENTER]
    2) Type COPY CON CONFIG.SYS[ENTER]
    3) Type BUFFERS=20[ENTER]
    4) Type FILES=20[ENTER]
    5) Type DEVICE=MOUSE.SYS[ENTER] (use this if you are 
		using a MOUSE.SYS file)
    6) Press the F6 key and then the [ENTER] key.

Step 5. Reboot your machine with your new SimLife boot disk 
in drive A:. When you finish playing, remove the disk from 
the drive and reboot from the hard disk to return to your 
normal setup.


III.  SCENARIO INFORMATION

-> Building a New World While Playing a Scenario
Building a new world while playing a scenario will not exit 
or restart the scenario. The only scenario this has any real 
bearing on is the March Of The Mutants, where the simulator 
will re-populate the world on a yearly basis. To quit a 
scenario completely, you can either start a New Game, Load a 
Saved Game, or Quit SimLife entirely.

-> A Little Terminology Confusion
In most of the program and manual, SimLife organisms are 
called Organisms. Sometimes in scenarios, the word Orgot is 
used as an overall name for Artificial Life Organisms. And 
then again, there is an individual animal species in SimLife 
that is called Orgot. Just letting you know that you have 
the right to be confused. Sorry.

-> Orgot Names in March Of The Mutants
In order to make tracking the progression of your mutants 
easier, the names assigned to newly created mutant orgots 
contain useful information. The first letter of the species 
name will be either a "P" for plant species or an "A" for 
animal species. The numbers following are the initial 
creation date of the creature followed by its position on 
the Dashboard (separated by a period). Thus, the orgot 
"A123.4" is an animal created in the 123rd year of the 
simulation that occupied slot number 4 on the Dashboard when 
it was created. 

IV.  INCLUDED FILES

Along with the game files, there are also a couple of 
directories full of delight. One is the Orgot directory, 
filled with various plants, animals and zoos (collections of 
plants or animals). Make sure you keep a good backup of 
these on a floppy disk, since everyone has a tendency to 
modify the plants and animals on the hard disk and then want 
the old ones back.

We've also included a directory of saved games that show how 
you can use the SimLife simulation to simulate stuff other 
than life. Each of these saved games has a small description 
in the GAMES.TXT file.

V.  A LITTLE Q&A

This section is by no means complete, but it should help. We 
thought we'd try to stick in a few of the questions that we 
had a hard time with.

Q. Why do my orgots sometimes seem to get stuck in one spot?
A. Orgots have genes that limit their movement across the 
terrain. The most common problem is that an orgot will get 
stuck on a mountain or in a valley and if it does not have 
its climb gene set, will be unable to escape (even to follow 
the carrot).

Q. Why don't my orgots follow trails like bloodhounds?
A. Orgots will break away from a trail if they get thirsty 
or hungry for another animal. Try using the Variables Window 
on the orgot that you think should be following a trail and 
see how its food and water levels affect its trail 
following. Keep in mind that trails are dependent on an 
animal's Stealth gene. The lower an animal's Stealth is, the 
more likely it is to break branches, leave footprints, or 
leave a scent when moving about. Try changing an animal's 
stealth and observe the trail it leaves in the map window. A 
less stealthy animal's trail will be a solid line, while a 
more stealthy animal will leave a broken trail. On the 
pursuer's side, Vision and Persistence are the most 
important genetic factors, as well as the animal's Attract 
gene. The higher an animal's Vision is, the more likely it 
is to see a trail and be able to follow it. The more 
persistent it is, the less likely it will be to lose the 
trail or give up on it.

Q. Why doesn't my plant sprout when I increase its age or 
size in the Show Variables window?
A. Plant sprouting is not a function of its age or size. A 
seed can stay in the ground for years before conditions are 
good enough for sprouting to take place. It is the season, 
temperature, and moisture that cause sprouting. If a seed 
gets too old without sprouting, it will die.

VI.  CHEATS
SimLife has many "cheat" commands that can be used to modify 
or improve the experience.  Where caps are requested, you will 
need to hold the Caps Lock key rather than the Shift key to 
avoid bringing up some of the other keyboard shortcuts.

-> Typing WEIS turns the raise/lower Altitude tool (on the 
Edit Window Control Panel) into a raise/lower Soil Depth 
tool that allows you to change the soil depth in the same 
manner as you would change the altitude, rainfall, or 
temperature.

-> Typing WALL will turn the Barrier tool into a Wall tool 
and all barriers into walls. Flying animals may fly over 
barriers, but not over walls.

-> Typing WIPE will erase all statistics, trails, history 
information, and such. This can be very helpful when making 
changes in a situation where you don't want the old data 
mixed with the new. Think of it as the History Eraser 
Button. 
